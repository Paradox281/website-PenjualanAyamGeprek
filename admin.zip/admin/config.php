<?php
$mata_uang = 'Rp.';
$db_host = 'localhost';
$db_username ='root';
$db_password ='';
$db_name = 'geprek';

$mysqli = new mysqli($db_host,$db_username,$db_password,$db_name);
?>